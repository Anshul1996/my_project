package com.example.anshul.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.widget.ScrollView;

import android.widget.TextView;
import android.graphics.Color;

public class Showappointment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showappointment);
        Intent intent=getIntent();
        String FName = intent.getStringExtra("fname");
        String FAppoint = intent.getStringExtra("fappoint");
        String FDate = intent.getStringExtra("fdate");
        String FTime = intent.getStringExtra("ftime");

        TextView textView1 = new TextView(this);
        TextView textView2 = new TextView(this);
        TextView textView3 = new TextView(this);
       // TextView textView4 = new TextView(this);
       // TextView textView5 = new TextView(this);
       // TextView textView6 = new TextView(this);
       // TextView textView7 = new TextView(this);
       // TextView textView8 = new TextView(this);
        textView2.setTextSize(35);
        textView2.setText("Appointment is Booked with Following Details.Please Note\n\n");
        textView2.setTextColor(Color.RED);

        textView1.setTextSize(30);
        textView1.setText("\n\n\n\nPatient_Name : "+ FName+"\n\nAppointment_Type :"+FAppoint+"\n\nAppointment_Date :"+FDate+"\n\nAppointment_Time :"+FTime);
       // textView5.setText("");
       // textView2.setText("Appointment_Type : "+FAppoint+"\n");
       // textView3.setText("Appointment_Date : "+FDate+"\n");
       // textView4.setText("Appointment_Time : "+FTime+"\n");



        RelativeLayout layout = (RelativeLayout) findViewById(R.id.content1);
        layout.addView(textView2);
       layout.addView(textView1);
        /*layout.addView(textView2);
        layout.addView(textView3);
        layout.addView(textView4);*/


    }
}
