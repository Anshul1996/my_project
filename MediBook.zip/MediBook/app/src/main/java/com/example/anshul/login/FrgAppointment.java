package com.example.anshul.login;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class FrgAppointment extends Fragment {
    SQLiteDatabase db;
    ListView Ls;
    ArrayList<String> str;
    ArrayAdapter<String> adapter;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_frg_appointment,container,false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Intent intent=new Intent(getActivity(),Showappointment.class);
        startActivity(intent);






       /* DatabaseHelper databaseHelper=new DatabaseHelper(getActivity(),"RECORD",null,3);
        db=databaseHelper.getWritableDatabase();
        Cursor cursor=db.rawQuery("Select P_NAME ,P_TYPE ,P_DATE ,P_TIME from APPOINTMENT",null);
        if(cursor.moveToNext()) {
            String a = cursor.getString(0);
            String b = cursor.getString(1);
            String c = cursor.getString(2);
            String d = cursor.getString(3);

            Ls.add(a+b);




        }
           TextView textView1 = new TextView(getActivity());
            TextView textView2 = new TextView(getActivity());
            TextView textView3 = new TextView(getActivity());
            TextView textView4 = new TextView(getActivity()) ;
            textView1.setText(a+"\n");
            textView2.setText("\n"+b);

            FrameLayout layout=new FrameLayout(getActivity());
            layout.addView(textView1);
            layout.addView(textView2);

            Ls=(ListView)getActivity().findViewById(R.id.listView11);
            ArrayAdapter adapter2 = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1,);
            Ls.setAdapter(adapter2);


*/
      //  openAndQueryDatabase();
        //displayResultList();

    }
    /*public void openAndQueryDatabase() {
        try {
            DatabaseHelper databaseHelper=new DatabaseHelper(getActivity(),"RECORD",null,3);
            db=databaseHelper.getWritableDatabase();
            Cursor c = db.rawQuery("Select P_NAME,P_TYPE,P_DATE,P_TIME  from APPOINTMENT", null);
            if (c != null ) {
                if  (c.moveToFirst()) {
                    do {
                        String Name = c.getString(c.getColumnIndex("P_NAME"));
                        String Type = c.getString(c.getColumnIndex("P_TYPE"));
                        String Date = c.getString(c.getColumnIndex("P_DATE"));
                        String Time = c.getString(c.getColumnIndex("P_TIME"));


                        //int age = c.getInt(c.getColumnIndex("Age"));

                        str.add("Name: " + Name + ",Type: " + Type + ",Date: " + Date + ",Time: "+ Time);
                    }while (c.moveToNext());
                }
            }
        } catch (SQLiteException se ) {
            Log.e(getClass().getSimpleName(), "Could not create or Open the database");
        } finally {
            if (db != null)
                db.execSQL("DELETE FROM APPOINTMENT");
            db.close();
        }
    }*/
    //public void displayResultList() {
       // TextView tView = new TextView(getActivity());
       // tView.setText("This data is retrieved from the database and only 4 " +
              //  "of the results are displayed");
        //getListView().addHeaderView(tView);
      //  Ls=(ListView)getActivity().findViewById(R.id.listView11);
        /*setListAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, results));
        getListView().setTextFilterEnabled(true);
    */
       /* Ls,setad(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, str);

        ArrayAdapter adapter2 = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1,str );
        Ls.setAdapter(adapter2);*/
        //Ls.setAdapter(new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1 , str));
//Ls.setAdapter();

     /*   Ls=(ListView)getActivity().findViewById(R.id.listView1);
        ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, str);
        Ls.setAdapter(adapter);

    }*/

    }





