package com.example.anshul.login;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Appointment extends Activity implements AdapterView.OnItemSelectedListener,View.OnClickListener {
    Spinner spinner1;
    EditText txtDate, txtTime,txtName;
    Button btn_a;
    private int mYear, mMonth, mDay, mHour, mMinute;

    SQLiteDatabase db;
   // public final static String EXTRA_MESSAGE="com.example.anshul.login.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);
        spinner1 = (Spinner) findViewById(R.id.spin1);

        spinner1.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        categories.add("Audiologist");
        categories.add("Allergist");
        categories.add("Cardiologist");
        categories.add("Dentist");
        categories.add("Dermatologist");
        categories.add("ENTspecialist");
        categories.add("Gynecologist");
        categories.add("Microbiologist");
        categories.add("Neurologist");
        categories.add("Osteologist");
        categories.add("Oncologist");
        categories.add("Psychiatrist");
        categories.add("Surgeon");
        categories.add("Urologist");
        categories.add("Others");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(dataAdapter);

        txtDate = (EditText) findViewById(R.id.editdate);
        txtTime = (EditText) findViewById(R.id.editTime);

        txtDate.setOnClickListener(this);
        txtTime.setOnClickListener(this);
        DatabaseHelper databaseHelper=new DatabaseHelper(getApplicationContext(),"RECORD",null,3);
        db=databaseHelper.getWritableDatabase();
btn_a=(Button)findViewById(R.id.button1);
        btn_a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText edit=(EditText)findViewById(R.id.editText1);
                String mess1=edit.getText().toString();
                String mess2=spinner1.getSelectedItem().toString();
                String mess3=txtDate.getText().toString();
                String mess4=txtTime.getText().toString();
                ContentValues jk=new ContentValues();
                jk.put("P_NAME",mess1);
                jk.put("P_TYPE",mess2);
                jk.put("P_DATE", mess3);
                jk.put("P_TIME", mess4);
                long p=db.insert("APPOINTMENT",null,jk);
                if(p>0)
                {
                sendMessage();
                }
            else
                {
                    Toast.makeText(Appointment.this, "Invalid Detail ", Toast.LENGTH_LONG).show();
                }
            }
        });

    }


    public void sendMessage() {
        Intent intent=new Intent(Appointment.this,Showappointment.class);

        EditText edit1=(EditText)findViewById(R.id.editText1);
        String message1=edit1.getText().toString();
        String message2=spinner1.getSelectedItem().toString();
        String message3=txtDate.getText().toString();
        String message4=txtTime.getText().toString();
        intent.putExtra("fname",message1);
        intent.putExtra("fappoint",message2);
        intent.putExtra("fdate",message3);
        intent.putExtra("ftime",message4);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        //    String item = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {

        if (v == txtDate) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText("     "+dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == txtTime) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            txtTime.setText("     "+hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();


        }
    }
   /* public void sendMessage(View view){
        Intent intent=new Intent(Appointment.this,Showappointment.class);

        EditText edit1=(EditText)findViewById(R.id.editText1);
        String message1=edit1.getText().toString();
        intent.putExtra(EXTRA_MESSAGE,message1);
        startActivity(intent);

    }*/
}
