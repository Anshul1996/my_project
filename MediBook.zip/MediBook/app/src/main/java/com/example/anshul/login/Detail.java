package com.example.anshul.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class Detail extends AppCompatActivity {
    Spinner dropdown;
    Button btn_1;
    EditText edname;
    EditText edfatname;
    RadioGroup Radgen;
    RadioGroup Radmart;
    EditText edage;
    EditText edemail;
    EditText edphone;
    RadioGroup Radins;
    EditText edAdd;
    Spinner edState;
    public static final String MyPREFERENCES = "MyPrefs" ;
    public static final String Name = "nameKey";
    public static final String FName = "fnameKey";
    public static final String PHone = "phoneKey";
    public static final String E_mail = "emailKey";
   // public static final String Address = "addresskey";
    public static final String Gender = "genderkey";
    public static final String Martial = "martialkey";
    public static final String Age = "agekey";

SharedPreferences sharedPreferences;

    String[] state = {"Select", "Assam", "Andhra Pradesh", "Arunachal Pradesh", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
            "Nagaland", "Orissa", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Telangana",
            "Andaman and Nicobar Islands", "Chandigarh", "Dadar and Nagar Haveli", "Daman and Diu", "Delhi", "Lakshadweep", "Pondicherry"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Intent intent=getIntent();


        btn_1=(Button)findViewById(R.id.but1);
        dropdown = (Spinner) findViewById(R.id.Snamee);
        ArrayAdapter adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, state);
        adapter1.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        dropdown.setAdapter(adapter1);

        sharedPreferences = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);

      btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               edname=(EditText)findViewById(R.id.namee);
                edfatname=(EditText)findViewById(R.id.fnamee);
                Radgen=(RadioGroup)findViewById(R.id.Gnamee);
                Radmart=(RadioGroup)findViewById(R.id.Mnamee);
                edage=(EditText)findViewById(R.id.Anamee);
                edemail=(EditText)findViewById(R.id.Enamee);
                edphone=(EditText)findViewById(R.id.Pnamee);

                Radins=(RadioGroup)findViewById(R.id.menamee);

                edAdd=(EditText)findViewById(R.id.Adnamee);
                edState=(Spinner)findViewById(R.id.Snamee);

                String name = edname.getText().toString();
                String Fathername = edfatname.getText().toString();
                String Age= edage.getText().toString();
                String Email = edage.getText().toString();
                String Phone = edphone.getText().toString();
                String Address = edAdd.getText().toString();
                //String State = edState.getText().toString();

                if (name.isEmpty()) {
                    Toast.makeText(Detail.this,"Some Fields are empty", Toast.LENGTH_LONG).show();

                } else if(Fathername.isEmpty()){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Age.isEmpty()){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Email.isEmpty()){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Phone.isEmpty()){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Address.isEmpty()){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }

                else if(Radgen.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Radmart.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }
                else if(Radins.getCheckedRadioButtonId() == -1){
                    Toast.makeText(Detail.this, "Some Fields are empty", Toast.LENGTH_LONG).show();

                }


                else{

              /*  SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString("Name",name);
                    editor.putString("FName",Fathername);
                   // editor.putString(Gender,Radgen);

                    editor.putString("E_mail",Email);
                    editor.putString("PHone",Phone);
                    editor.commit();*/
                    Intent intent = new Intent(Detail.this, UserDetail.class);
                    intent.putExtra("fname",name);
                    intent.putExtra("ffather",Fathername);
                    intent.putExtra("fAge",Age);
                    intent.putExtra("femail",Email);
                    intent.putExtra("fphone",Phone);
                   // intent.putExtra("")



                    //Intent i = new Intent(Detail.this, UserDetail.class);
                    startActivity(intent);
               }
            }


        });
   }
}
