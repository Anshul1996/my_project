package com.example.anshul.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class UserDetail extends AppCompatActivity {
//SharedPreferences sharedPreferences;
    Button bto1;
    TextView textView1,textView2,textView3,textView4,textView5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);
       /* sharedPreferences = getSharedPreferences("MyPREFERENCES", Context.MODE_PRIVATE);

      //  SharedPreferences sharedPreferences = getSharedPreferences("MY_SHARED_PREF", MODE_PRIVATE);
        String strSavedMem1 = sharedPreferences.getString("Name","");
        String strSavedMem2 = sharedPreferences.getString("FName","");
        String strSavedMem3 = sharedPreferences.getString("E_mail","");

        String strSavedMem4 = sharedPreferences.getString("PHone","");



       textView1.setText(strSavedMem1);
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.content2);
        layout.addView(textView1);
       // textSavedMem2.setText(strSavedMem2);*/
        textView1=(TextView)findViewById(R.id.textView13);
        textView2=(TextView)findViewById(R.id.textView14);
        textView3=(TextView)findViewById(R.id.textView15);
        textView4=(TextView)findViewById(R.id.textView16);
        textView5=(TextView)findViewById(R.id.textView17);
        bto1=(Button)findViewById(R.id.button01);
        Intent intent=getIntent();
        String nnname= intent.getStringExtra("fname");
        String Ffther = intent.getStringExtra("ffather");
        String ffge = intent.getStringExtra("fAge");
        String eeemail = intent.getStringExtra("femail");
        String pone= intent.getStringExtra("fphone");

        //TextView textView1 = new TextView(this);
        //TextView textView2 = new TextView(this);
        textView1.setText("User_Name : "+nnname);
        textView2.setText("Father_Name : "+Ffther);
         textView3.setText("Age : "+ffge);
        textView4.setText("Email :" +eeemail);
        textView5.setText("Phone : "+pone);
       // RelativeLayout layout = (RelativeLayout) findViewById(R.id.content2);
       // layout.addView(textView1);
       // layout.addView(textView2);
        //;
      bto1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(UserDetail.this,Navigation.class);
                startActivity(intent);
            }
        });




    }
}
