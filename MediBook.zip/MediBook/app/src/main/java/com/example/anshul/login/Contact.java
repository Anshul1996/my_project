package com.example.anshul.login;

/**
 * Created by Anshul on 6/10/2016.
 */
public class Contact {
    int id;
    String name,email,pass;
    public void setId(int id)
    {
        this.id=id;
    }
    public int getId()
    {
        return this.id;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public String getName()
    {
        return this.name;
    }
    public void setEmail(String email)
    {
        this.name=name;
    }
    public String getEmail()
    {
        return this.email;
    }
    public void setPass(String pass)
    {
        this.pass=pass;
    }
    public String getPass()
    {
        return this.pass;
    }
}
