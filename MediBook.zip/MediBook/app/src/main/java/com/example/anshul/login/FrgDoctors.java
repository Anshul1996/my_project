package com.example.anshul.login;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class FrgDoctors extends Fragment {
    ListView li;
    String[] loc={"Dr. Ravi Kumar (M.D)","Dr.Hardeep Singh (Cardiologist)","Dr. Anil Chawala (Osteology)","Dr.Seema Mehta (Neurologist) ","Dr.Ammy Sharma (Audiologist)","Dr.Chaman Gupta (Dentist)","Dr.Rohit Kumar (Dermatologist)","Dr.Ankita(Gynecologist)","Dr.Randeep Singh(ENT)","Dr.Saurabh (Psychiatrist)","Dr.Amit Kumar (Surgeon)","Dr.Ankit (Urologist)","Dr.Umesh Gupta (Oncologist)","Dr.Harpreet Sandhu (Microbiologist)","Dr.Sanjay Mahajan (Allergist)"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_frg_doctors,container,false);

     /*  li=(ListView)getActivity().findViewById(R.id.listView1);
        ArrayAdapter adapter2 = new ArrayAdapter(ge, android.R.layout.simple_list_item_1, loc);
        li.setAdapter(adapter2);*/

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        li=(ListView)getActivity().findViewById(R.id.listView1);
        ArrayAdapter adapter2 = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, loc);
        li.setAdapter(adapter2);

    }
}
